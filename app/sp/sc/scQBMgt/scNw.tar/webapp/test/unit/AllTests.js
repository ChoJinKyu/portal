sap.ui.define([
	"sp/sc/scNw/test/unit/controller/App.controller"
], function () {
	"use strict";
});
