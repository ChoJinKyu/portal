sap.ui.define([
	"sp/sc/scQBMgt/test/unit/controller/App.controller"
], function () {
	"use strict";
});
