sap.ui.define([
	"pg/tm/tmMonitoring/test/unit/controller/Monitor.controller"
], function () {
	"use strict";
});
