sap.ui.define([
	"ext/lib/UIComponent"
], function (UIComponent) {
	"use strict";

	return UIComponent.extend("pg.mi.miPrice.Component", {

		metadata : {
			manifest: "json"
		}

	});

});